package bd.edu.seu.classproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
